import pandas as pd, numpy as np, json
va=json.load(open('val_acc.json')); TAU=0.75
out={}
for N in (20,50):
    d=pd.read_csv(f'fair_benchmark_grid{N}.csv')
    d['val_acc']=d.env.map(va)
    feas=set(d[(d.algorithm=='A*')&(d.success==True)].env)
    # gated row
    g=[]
    for e in d.env.unique():
        v=va.get(e); src='NACHA* (w=1.2)' if (v is not None and v>=TAU) else 'wA* (w=1.2)'
        r=d[(d.env==e)&(d.algorithm==src)].iloc[0].copy(); r['algorithm']='NACHA* gated'; r['gate_on']=src.startswith('NACHA'); g.append(r)
    d=pd.concat([d,pd.DataFrame(g)],ignore_index=True)
    d['reliable']=d.val_acc>=TAU
    a=d[d.algorithm=='A*'].set_index('env')
    d['node_red']=d.apply(lambda r: a.loc[r.env,'nodes']/r.nodes if r.get('success')==True and r.nodes>0 else np.nan,axis=1)
    d['speedup']=d.apply(lambda r: a.loc[r.env,'time_s']/r.time_s if r.get('success')==True and r.time_s>0 else np.nan,axis=1)
    d.to_csv(f'analysis_grid{N}.csv',index=False)
    f=d[d.env.isin(feas)]
    order=['A*','wA* (w=1.2)','NACHA*-S (w=1.0)','NACHA* (w=1.2)','NACHA* gated','Oracle-risk (w=1.2)']
    def agg(x):
        s=x[x.success==True]
        return pd.Series(dict(n=len(x),success=100*len(s)/len(x),nodes=s.nodes.mean(),time_ms=1000*s.time_s.mean(),
            nodered_med=s.node_red.median(),speed_med=s.speedup.median(),speed_max=s.speedup.max(),
            subopt_mean=s.subopt_pct.mean(),subopt_max=s.subopt_pct.max(),minclr=s.min_clearance.mean(),meanclr=s.mean_clearance.mean()))
    for sub,lab in ((f,'all feasible'),(f[f.reliable==True],'reliable'),(f[f.reliable!=True],'unreliable')):
        t=sub.groupby('algorithm').apply(agg).reindex(order).round(3)
        print(f'\n### N={N} {lab} (envs={sub.env.nunique()})'); print(t.to_string())
        out[(N,lab)]=t
    pre=d[(d.algorithm=='NACHA* (w=1.2)')&d.precompute_s.notna()].precompute_s*1000
    print('precompute ms median',pre.median(),'max',pre.max())
    print('reliable feasible envs:',sorted(f[f.reliable==True].env.unique()))
pd.to_pickle(out,'agg.pkl')
