"""
Environment model loader - Version i përditësuar me TorchScript JIT Optimization dhe Normalizim të Saktë.
"""

import os
import warnings
import numpy as np
import torch
import torch.nn as nn

# Fik warnings për weights_only
warnings.filterwarnings("ignore", category=UserWarning)


class SimpleNN(nn.Module):
    """Neural network model që përputhet me peshat e ruajtura në .pt (net.0, net.1, etj.)."""
    def __init__(self, hidden_sizes=None):
        super().__init__()
        
        # Struktura e korrigjuar me përmasat e sakta: 128 -> 64 -> 32 -> 1
        self.net = nn.Sequential(
            nn.Linear(3, 128),     # net.0
            nn.BatchNorm1d(128),   # net.1
            nn.ReLU(),             # net.2
            nn.Dropout(0.1),       # net.3
            nn.Linear(128, 64),    # net.4
            nn.BatchNorm1d(64),    # net.5
            nn.ReLU(),             # net.6
            nn.Dropout(0.1),       # net.7
            nn.Linear(64, 32),     # net.8
            nn.BatchNorm1d(32),    # net.9
            nn.ReLU(),             # net.10
            nn.Linear(32, 1),      # net.11
            nn.Sigmoid()           # Sigmoid për dalje [0, 1]
        )

    def forward(self, x):
        return self.net(x)


class EnvModel:
    """
    Environment model loader me mbështetje për TorchScript (JIT) dhe normalizim të saktë.
    
    Args:
        model_path (str): Rruga drejt skedarit të modelit (.pt, .pth, ose .npz)
        grid_size (int): Madhësia e grid-it 3D (p.sh. 20, 50)
        normalize (bool): Nëse true, normalizon input-in në [0, 1] duke përdorur grid_size-1
    """
    
    def __init__(self, model_path, grid_size=20, normalize=True):
        self.model_path = model_path
        self.grid_size = grid_size
        self.normalize = normalize
        self.normalizer = float(grid_size - 1) if normalize else 1.0
        
        self.model_type = None
        self.hidden_sizes = [128, 128, 64]
        self.torch_model = None
        self.val_accuracy = None
        self.genome = None
        self.W1 = self.W2 = self.W3 = None
        self.B1 = self.B2 = self.B3 = None
        
        self._load_model(model_path)

    def _optimize_torch_model(self):
        """Konverton modelin në TorchScript JIT për performancë maksimale në CPU."""
        if self.torch_model is None:
            return
            
        self.torch_model.eval()
        for param in self.torch_model.parameters():
            param.requires_grad = False
            
        try:
            # Shembull hyrjeje me Batch Size > 1 për të mos pasur probleme me BatchNorm1d
            example_input = torch.zeros((2, 3), dtype=torch.float32)
            traced_model = torch.jit.trace(self.torch_model, example_input)
            self.torch_model = torch.jit.optimize_for_inference(traced_model)
            print("      🚀 TorchScript JIT optimization successful!")
        except Exception as e:
            print(f"      ⚠️ TorchScript optimization bypassed: {e}")

    def _load_model(self, model_path):
        """Load model from file."""
        
        # 1. Try .npz (GA model)
        if model_path.endswith('.npz'):
            try:
                data = np.load(model_path, allow_pickle=True)
                self.genome = data['genome']
                self.hidden_sizes = data['hidden_sizes'].tolist() if hasattr(data['hidden_sizes'], 'tolist') else list(data['hidden_sizes'])
                self.input_size = int(data['input_size'])
                self.output_size = int(data['output_size'])
                self.model_type = 'numpy'
                self._decode_numpy()
                print(f"   ✅ Loaded GA model from: {model_path}")
                return
            except Exception as e:
                print(f"   ❌ Error loading .npz: {e}")

        # 2. Try .pt (PyTorch model)
        if model_path.endswith('.pt') or model_path.endswith('.pth'):
            try:
                checkpoint = torch.load(model_path, map_location='cpu', weights_only=False)
                
                # Krijojmë modelin e ri
                raw_model = SimpleNN()
                
                # Marrim peshat në varësi të strukturës ku janë ruajtur
                if isinstance(checkpoint, dict) and 'model_state_dict' in checkpoint:
                    state_dict = checkpoint['model_state_dict']
                elif isinstance(checkpoint, dict) and 'state_dict' in checkpoint:
                    state_dict = checkpoint['state_dict']
                else:
                    state_dict = checkpoint
                
                raw_model.load_state_dict(state_dict)
                raw_model.eval()
                
                self.torch_model = raw_model
                self.model_type = 'torch'
                self.val_accuracy = checkpoint.get('val_accuracy', None) if isinstance(checkpoint, dict) else None
                
                print(f"   ✅ Loaded PyTorch model from: {model_path}")
                if self.val_accuracy is not None:
                    print(f"      Val Accuracy: {self.val_accuracy:.3f}")
                
                # Zbatim i optimizimit JIT
                self._optimize_torch_model()
                return
                
            except Exception as e:
                print(f"   ❌ Error loading .pt: {e}")

        # 3. Fallback - Krijojmë model fallback nëse dështon ngarkimi
        print("   ⚠️ Using fallback - creating random model for testing")
        self.torch_model = SimpleNN()
        self.torch_model.eval()
        self.model_type = 'torch_fallback'
        self.val_accuracy = 0.5
        self._optimize_torch_model()

    def _decode_numpy(self):
        """Decode genome from .npz file."""
        h1, h2 = self.hidden_sizes[:2]
        idx = 0
        
        self.W1 = self.genome[idx:idx + self.input_size * h1].reshape(self.input_size, h1)
        idx += self.input_size * h1
        self.B1 = self.genome[idx:idx + h1]
        idx += h1
        
        self.W2 = self.genome[idx:idx + h1 * h2].reshape(h1, h2)
        idx += h1 * h2
        self.B2 = self.genome[idx:idx + h2]
        idx += h2
        
        self.W3 = self.genome[idx:idx + h2 * self.output_size].reshape(h2, self.output_size)
        idx += h2 * self.output_size
        self.B3 = self.genome[idx:idx + self.output_size]

    def _normalize_points(self, points):
        """
        Normalizon pikat në intervalin [0, 1] duke përdorur normalizer-in e saktë.
        
        Args:
            points: Listë pikash ose numpy array me forma (N, 3)
            
        Returns:
            numpy array me pikat e normalizuara
        """
        points_arr = np.array(points, dtype=np.float32)
        
        if self.normalize:
            return points_arr / self.normalizer
        else:
            return points_arr

    def predict(self, p):
        """
        Predict probability for a single point.
        
        Args:
            p: Tuple ose listë me 3 koordinata (x, y, z)
            
        Returns:
            float: Probabiliteti në [0, 1]
        """
        return self.predict_batch([p])[0]

    def predict_batch(self, points):
        """
        Batch prediction i optimizuar me PyTorch JIT / NumPy.
        
        Args:
            points: Listë pikash [(x1,y1,z1), (x2,y2,z2), ...] ose numpy array
            
        Returns:
            list: Listë me probabilitete në [0, 1]
        """
        # FIX: `if not points` fails for numpy arrays (ambiguous truth value),
        # which previously made predict_grid() crash and the risk field fall back to zeros.
        if points is None or len(points) == 0:
            return []
            
        # Normalizimi i saktë
        normalized_points = self._normalize_points(points)
            
        if self.model_type in ['torch', 'torch_fallback']:
            if self.torch_model is not None:
                # Përdorim Tensor direkt me torch.inference_mode() për shpejtësi maksimale
                x = torch.tensor(normalized_points, dtype=torch.float32)
                
                # Nëse pika është vetëm 1, duhet të jetë në formën (1, 3)
                if x.ndim == 1:
                    x = x.unsqueeze(0)
                
                with torch.inference_mode():
                    results = self.torch_model(x).squeeze(-1)
                    if results.ndim == 0:
                        results = results.unsqueeze(0)
                    return [max(0.0, min(1.0, float(r))) for r in results.tolist()]

        elif self.model_type == 'numpy':
            x = normalized_points
            h = np.maximum(0, x @ self.W1 + self.B1)
            h = np.maximum(0, h @ self.W2 + self.B2)
            out = 1 / (1 + np.exp(-(h @ self.W3 + self.B3)))
            return [max(0.0, min(1.0, float(v))) for v in out.flatten().tolist()]

        # Fallback
        return [0.5] * len(points)

    def predict_grid(self, grid_size=None):
        """
        Llogarit parashikimin për të gjithë grid-in 3D.
        
        Args:
            grid_size: Madhësia e grid-it (nëse None, përdor self.grid_size)
            
        Returns:
            np.ndarray: Matricë 3D me probabilitete në [0, 1]
        """
        if grid_size is None:
            grid_size = self.grid_size
        
        # Krijo të gjitha pikat e grid-it
        xs, ys, zs = np.meshgrid(
            np.arange(grid_size, dtype=np.float32),
            np.arange(grid_size, dtype=np.float32),
            np.arange(grid_size, dtype=np.float32),
            indexing='ij'
        )
        
        all_points = np.stack([
            xs.ravel(),
            ys.ravel(),
            zs.ravel()
        ], axis=1)
        
        # Parashiko në batch
        preds = self.predict_batch(all_points)
        preds_arr = np.array(preds, dtype=np.float32)
        
        # Rishiko formën në 3D
        if preds_arr.size == grid_size ** 3:
            return preds_arr.reshape((grid_size, grid_size, grid_size))
        else:
            print(f"   ⚠️ Warning: Expected {grid_size**3} predictions, got {preds_arr.size}")
            return np.zeros((grid_size, grid_size, grid_size), dtype=np.float32)

    def get_info(self):
        """Kthen informacion rreth modelit."""
        return {
            'model_path': self.model_path,
            'model_type': self.model_type,
            'grid_size': self.grid_size,
            'normalizer': self.normalizer,
            'normalize': self.normalize,
            'hidden_sizes': self.hidden_sizes,
            'val_accuracy': self.val_accuracy
        }

    def set_grid_size(self, grid_size):
        """
        Ndryshon grid_size dhe rillogarit normalizer-in.
        
        Args:
            grid_size (int): Madhësia e re e grid-it
        """
        self.grid_size = grid_size
        self.normalizer = float(grid_size - 1) if self.normalize else 1.0
        print(f"   🔄 Grid size updated to: {grid_size}, normalizer: {self.normalizer}")


# ============================================================
# FUNKSIONE NDIHMËSE PËR KREIMIN E MODELIT
# ============================================================

def create_env_model(model_path, grid_size=20, normalize=True):
    """
    Funksion ndihmës për krijimin e një instance të EnvModel.
    
    Args:
        model_path (str): Rruga drejt skedarit të modelit
        grid_size (int): Madhësia e grid-it
        normalize (bool): Nëse true, normalizon input-in
        
    Returns:
        EnvModel: Instanca e modelit
    """
    return EnvModel(model_path, grid_size=grid_size, normalize=normalize)


def load_model_for_environment(env_name, grid_size=20, model_dir=None):
    """
    Ngarkon modelin për një environment specifik.
    
    Args:
        env_name (str): Emri i environment-it
        grid_size (int): Madhësia e grid-it
        model_dir (str): Drejtoria ku ndodhen modelet (nëse None, përdor default)
        
    Returns:
        EnvModel: Instanca e modelit ose None nëse nuk gjendet
    """
    if model_dir is None:
        model_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'models')
    
    # Provo modele të ndryshme për këtë environment
    possible_paths = [
        os.path.join(model_dir, f'env_model_{env_name}_backprop.pt'),
        os.path.join(model_dir, f'env_model_{env_name}.pt'),
        os.path.join(model_dir, f'env_model_{env_name}.pth'),
        os.path.join(model_dir, f'env_model_{env_name}.npz'),
        os.path.join(model_dir, 'env_model_cube_backprop.pt'),  # Fallback
        os.path.join(model_dir, 'env_model_cube.pt'),           # Fallback
    ]
    
    for path in possible_paths:
        if os.path.exists(path):
            try:
                return EnvModel(path, grid_size=grid_size)
            except Exception as e:
                print(f"   ⚠️ Failed to load {path}: {e}")
                continue
    
    print(f"   ❌ No model found for environment: {env_name}")
    return None


# ============================================================
# TEST I SHPEJTË
# ============================================================
if __name__ == "__main__":
    print("=" * 70)
    print("🧪 TESTING EnvModel WITH CORRECT NORMALIZATION")
    print("=" * 70)
    
    # Test me grid_size=20
    print("\n📊 Test 1: grid_size = 20")
    test_path = "env_model/models/env_model_cube_backprop.pt"
    
    if os.path.exists(test_path):
        model = EnvModel(test_path, grid_size=20)
        print(f"\n📋 Model Info: {model.get_info()}")
        
        test_points = [(0, 0, 0), (5, 5, 5), (10, 10, 10), (15, 15, 15), (19, 19, 19)]
        print("\n🔮 Test predictions (grid_size=20):")
        preds = model.predict_batch(test_points)
        for p, prob in zip(test_points, preds):
            normalized = tuple(c / 19.0 for c in p)
            print(f"  {p} -> norm={normalized} -> prob={prob:.4f}")
    
    # Test me grid_size=50
    print("\n" + "-" * 70)
    print("\n📊 Test 2: grid_size = 50")
    
    if os.path.exists(test_path):
        model50 = EnvModel(test_path, grid_size=50)
        print(f"\n📋 Model Info: {model50.get_info()}")
        
        test_points50 = [(0, 0, 0), (12, 12, 12), (25, 25, 25), (37, 37, 37), (49, 49, 49)]
        print("\n🔮 Test predictions (grid_size=50):")
        preds50 = model50.predict_batch(test_points50)
        for p, prob in zip(test_points50, preds50):
            normalized = tuple(c / 49.0 for c in p)
            print(f"  {p} -> norm={normalized} -> prob={prob:.4f}")
    
    print("\n" + "=" * 70)
    print("✅ TEST COMPLETED")
    print("=" * 70)
