"""
benchmark_fair.py — corrected, reproducible benchmark for the NACHA* manuscript.

All graph-search variants share ONE implementation (nacha_planner.NACHAStar):
CLOSED list, FIFO tie-breaking, precomputed step costs. They differ only in
(w, lambda0, risk field), so every difference in the table is algorithmic.

Variants
  A*                       w=1.0, lambda0=0                  (optimal reference)
  wA* (w=1.2)              w=1.2, lambda0=0                  (ablation: weighting only)
  NACHA*-S (w=1.0)         w=1.0, lambda0=0.1, neural rho    (ablation: neural cost only)
  NACHA* (w=1.2)           w=1.2, lambda0=0.1, neural rho    (proposed)
  Oracle-risk (w=1.2)      w=1.2, lambda0=0.1, rho from exact distance transform
                           (upper reference: what a perfect risk field would give)

Metrics per environment: success, unique node expansions, median wall-clock time
over RUNS runs (search only; risk-field precomputation is reported separately),
geometric path length, sub-optimality vs A*, minimum and mean obstacle clearance
along the path (Euclidean distance transform, in voxels), neural-field accuracy.

Usage:  python benchmark_fair.py --grid 50 --runs 3 --jobs 2
"""
import argparse, contextlib, io, math, os, sys, time, warnings
from multiprocessing import Pool

import numpy as np
from scipy.ndimage import distance_transform_edt

warnings.filterwarnings("ignore")
BASE = os.path.dirname(os.path.abspath(__file__))
for p in (BASE, os.path.join(BASE, "env_model", "envs"), os.path.join(BASE, "datasets")):
    sys.path.insert(0, p)

from obstacle_manager_3d import ObstacleManager as OM          # noqa: E402
from movingai_loader import MovingAI3DLoader                    # noqa: E402
from nacha_planner.nacha_star import NACHAStar                  # noqa: E402

LAMBDA0 = 0.10
VARIANTS = [
    ("A*",                  dict(w=1.0, lam=0.0,     risk=None)),
    ("wA* (w=1.2)",         dict(w=1.2, lam=0.0,     risk=None)),
    ("NACHA*-S (w=1.0)",    dict(w=1.0, lam=LAMBDA0, risk="nn")),
    ("NACHA* (w=1.2)",      dict(w=1.2, lam=LAMBDA0, risk="nn")),
    ("Oracle-risk (w=1.2)", dict(w=1.2, lam=LAMBDA0, risk="oracle")),
]


def load_environments(N):
    envs = {}
    pats = OM.get_all_patterns(seed=42, grid_size=N, include_mixed=True,
                               include_movingai=False, include_stanford=True)
    for k, v in pats.items():
        envs[k] = ("synthetic", v)
    with contextlib.redirect_stdout(io.StringIO()):
        L = MovingAI3DLoader()
        for name in L.ALL_MOVINGAI_MAPS:
            obs = L.load_map(name, N)
            src = "movingai-file"
            if obs is None:
                obs = L._generate_fallback_map(name, N)
                src = "random-fallback"
            envs[name] = (src, obs)
    return envs


def neural_risk(name, N):
    path = os.path.join(BASE, "env_model", "models", f"env_model_{name}_backprop.pt")
    if not os.path.exists(path):
        return None, None
    from models.env_model_loader import EnvModel
    with contextlib.redirect_stdout(io.StringIO()):
        m = EnvModel(path, grid_size=N)
        t = time.perf_counter()
        risk = m.predict_grid(N).astype(np.float32)
        dt = time.perf_counter() - t
    return risk, dt


def path_len(p):
    return sum(math.dist(p[i], p[i + 1]) for i in range(len(p) - 1))


def run_env(args):
    name, src, raw, N, runs = args
    import torch
    torch.set_num_threads(1)
    s, g = (0, 0, 0), (N - 1,) * 3
    obs = set(tuple(o[:3]) for o in raw)
    obs.discard(s); obs.discard(g)
    occ = np.zeros((N,) * 3, bool)
    for o in obs:
        occ[o] = True
    edt = distance_transform_edt(~occ) if occ.any() else np.full(occ.shape, float(N))
    oracle = np.exp(-(edt - 1.0) / 2.0).astype(np.float32)
    oracle[occ] = 1.0
    nn, t_pre = neural_risk(name, N)
    acc = float(((nn > 0.5) == occ).mean()) if nn is not None else float("nan")
    rows = []
    ref_len = None
    for label, cfg in VARIANTS:
        risk = {"nn": nn, "oracle": oracle, None: None}[cfg["risk"]]
        if cfg["lam"] > 0 and risk is None:
            rows.append(dict(env=name, source=src, algorithm=label, note="no trained model"))
            continue
        times, path, nodes = [], None, 0
        for _ in range(runs):
            pl = NACHAStar(N, obs, lambda0=cfg["lam"], w=cfg["w"], risk_grid=risk,
                           use_adaptive_lambda=True)
            t = time.perf_counter()
            path = pl.plan(s, g)
            times.append(time.perf_counter() - t)
            nodes = pl.nodes_expanded
        row = dict(env=name, source=src, obstacles=len(obs), density=len(obs) / N ** 3,
                   algorithm=label, success=path is not None, nodes=nodes,
                   time_s=float(np.median(times)),
                   precompute_s=(t_pre if cfg["risk"] == "nn" else 0.0),
                   nn_accuracy=acc)
        if path is not None:
            L = path_len(path)
            if label == "A*":
                ref_len = L
            cl = [edt[q] for q in path[1:-1]] or [float("nan")]
            row.update(length=L, min_clearance=float(np.min(cl)), mean_clearance=float(np.mean(cl)))
        rows.append(row)
    for r in rows:
        if ref_len and r.get("length"):
            r["subopt_pct"] = 100.0 * (r["length"] / ref_len - 1.0)
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--grid", type=int, default=50)
    ap.add_argument("--runs", type=int, default=3)
    ap.add_argument("--jobs", type=int, default=1)
    ap.add_argument("--out", default=None)
    a = ap.parse_args()
    import pandas as pd
    envs = load_environments(a.grid)
    jobs = [(k, src, obs, a.grid, a.runs) for k, (src, obs) in envs.items()]
    out = []
    with Pool(a.jobs) as pool:
        for i, rows in enumerate(pool.imap_unordered(run_env, jobs), 1):
            out.extend(rows)
            print(f"[{i}/{len(jobs)}] {rows[0]['env']}", flush=True)
    df = pd.DataFrame(out)
    fn = a.out or f"fair_benchmark_grid{a.grid}.csv"
    df.to_csv(fn, index=False)
    print("saved", fn)


if __name__ == "__main__":
    main()
