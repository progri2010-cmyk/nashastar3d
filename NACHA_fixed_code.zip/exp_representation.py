"""
exp_representation.py — neural risk field vs. Euclidean distance transform (EDT).

Part A (--part memory): memory and computation of the two clearance representations as the grid
resolution grows (N = 20, 50, 100, 200), for the per-map networks trained at 20^3.
  * occupancy grid (1 byte/voxel), EDT grid (float32), dense risk grid (float32), network weights
  * time to build the EDT field vs. time to evaluate the network on all N^3 voxels
  * lazy mode: NACHA* queries the network only for voxels it touches (memo cache); we report the
    number of network queries and the cache size, i.e. the memory actually needed at run time.

Part B (--part noise): robustness to map noise at 50^3. The planner only sees a corrupted map in
which a fraction p of free voxels become occupied (spurious returns) and a fraction p of occupied
voxels become free (missed returns). The risk field is either the EDT of the corrupted map or a
network trained on the corrupted map. Paths are evaluated against the TRUE map.
"""
import argparse, math, os, sys, time, json, contextlib, io
import numpy as np, pandas as pd, torch, torch.nn as nn
from scipy.ndimage import distance_transform_edt
BASE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, BASE)
sys.path.insert(0, os.path.join(BASE, "env_model", "envs"))
from obstacle_manager_3d import ObstacleManager as OM
from nacha_planner.nacha_star import NACHAStar
from models.env_model_loader import EnvModel, SimpleNN
torch.set_num_threads(1)
MAPS = ["cube", "spheres", "stanford_area_4", "wall_xy+wall_xz"]


def occ_of(name, N):
    occ = np.zeros((N,) * 3, bool)
    for part in name.split("+"):
        pts = np.array(getattr(OM, part)(grid_size=N), dtype=np.int64).reshape(-1, 3)
        if len(pts): occ[pts[:, 0], pts[:, 1], pts[:, 2]] = True
    occ[0, 0, 0] = occ[N - 1, N - 1, N - 1] = False
    return occ


def edt_risk(occ):
    d = distance_transform_edt(~occ) if occ.any() else np.full(occ.shape, float(occ.shape[0]))
    r = np.exp(-(d - 1.0) / 2.0).astype(np.float32); r[occ] = 1.0
    return r


def net_forward(model, pts, N):
    x = torch.from_numpy(pts.astype(np.float32) / (N - 1))
    with torch.inference_mode():
        return model(x).squeeze(-1).numpy()


def dense_nn(model, N, chunk=250_000):
    g = np.stack(np.meshgrid(*[np.arange(N)] * 3, indexing="ij"), -1).reshape(-1, 3)
    out = np.empty(len(g), np.float32)
    for i in range(0, len(g), chunk):
        out[i:i + chunk] = net_forward(model, g[i:i + chunk], N)
    return out.reshape(N, N, N)


class LazyRisk:
    """dict-like risk lookup that evaluates the network on demand and memoises the result."""
    def __init__(self, model, N):
        self.m, self.N, self.cache, self.calls = model, N, {}, 0

    def __getitem__(self, v):
        r = self.cache.get(v)
        if r is None:
            x, y, z = v
            nb = [(x + dx, y + dy, z + dz) for dx in (-1, 0, 1) for dy in (-1, 0, 1) for dz in (-1, 0, 1)
                  if 0 <= x + dx < self.N and 0 <= y + dy < self.N and 0 <= z + dz < self.N and (x + dx, y + dy, z + dz) not in self.cache]
            vals = net_forward(self.m, np.array(nb), self.N); self.calls += 1
            for p, val in zip(nb, vals): self.cache[p] = float(val)
            r = self.cache[v]
        return r


def load_net(name):
    with contextlib.redirect_stdout(io.StringIO()):
        em = EnvModel(os.path.join(BASE, "env_model", "models", f"env_model_{name}_backprop.pt"), grid_size=20)
    m = em.torch_model; m.eval(); return m


def clearance_stats(path, true_edt, true_occ):
    c = np.array([true_edt[q] for q in path[1:-1]])
    return dict(collision=bool(any(true_occ[q] for q in path)), min_clr=float(c.min()), mean_clr=float(c.mean()), near=float((c <= 2).mean()))


def part_memory(out):
    rows = []
    for name in ["cube", "spheres", "stanford_area_4"]:
        m = load_net(name); nparam = sum(p.numel() for p in m.parameters()); nbuf = sum(b.numel() for b in m.buffers())
        for N in (20, 50, 100, 200):
            occ = occ_of(name, N)
            t = time.perf_counter(); E = edt_risk(occ); t_edt = time.perf_counter() - t
            t = time.perf_counter(); R = dense_nn(m, N); t_nn = time.perf_counter() - t
            acc = float(((R > 0.5) == occ).mean())
            row = dict(env=name, N=N, voxels=N ** 3, occ_MB=occ.nbytes / 2 ** 20, field_MB=E.nbytes / 2 ** 20,
                       net_KB=(nparam + nbuf) * 4 / 1024, t_edt_s=t_edt, t_nn_dense_s=t_nn, nn_grid_acc=acc)
            if N <= 100:
                s, g = (0, 0, 0), (N - 1,) * 3; obs = set(map(tuple, np.argwhere(occ)))
                L = LazyRisk(m, N)
                t = time.perf_counter(); p = NACHAStar(N, obs, lambda0=0.1, w=1.2, risk_grid=L).plan(s, g); t_lazy = time.perf_counter() - t
                t = time.perf_counter(); p2 = NACHAStar(N, obs, lambda0=0.1, w=1.2, risk_grid=R).plan(s, g); t_dense = time.perf_counter() - t
                row.update(lazy_queries=len(L.cache), lazy_frac=len(L.cache) / N ** 3, lazy_cache_MB=len(L.cache) * 64 / 2 ** 20,
                           t_plan_lazy_s=t_lazy, t_plan_dense_s=t_dense, same_path=(p == p2))
            rows.append(row); print(row, flush=True)
    pd.DataFrame(rows).to_csv(out, index=False)


def train_net(occ, seed, samples=2000, epochs=150):
    N = occ.shape[0]; rng = np.random.default_rng(seed); torch.manual_seed(seed)
    ob, fr = np.argwhere(occ), np.argwhere(~occ)
    n = min(samples, len(fr))
    oi = rng.choice(len(ob), n, replace=len(ob) < n); fi = rng.choice(len(fr), n, replace=False)
    X = np.concatenate([ob[oi], fr[fi]]).astype(np.float32) / (N - 1); Y = np.concatenate([np.ones(n), np.zeros(n)]).astype(np.float32)
    perm = rng.permutation(len(X)); X, Y = X[perm], Y[perm]; k = int(0.8 * len(X))
    Xt, Yt, Xv, Yv = map(torch.from_numpy, (X[:k], Y[:k], X[k:], Y[k:]))
    m = SimpleNN(); opt = torch.optim.Adam(m.parameters(), lr=1e-3, weight_decay=1e-4); bce = nn.BCELoss()
    sch = torch.optim.lr_scheduler.ReduceLROnPlateau(opt, mode="max", factor=0.5, patience=15)
    best, state = -1, None
    for ep in range(epochs):
        m.train(); idx = torch.randperm(len(Xt))
        for i in range(0, len(Xt), 64):
            b = idx[i:i + 64]
            if len(b) < 2: continue
            opt.zero_grad(); l = bce(m(Xt[b]).squeeze(-1), Yt[b]); l.backward(); opt.step()
        if (ep + 1) % 10 == 0:
            m.eval()
            with torch.no_grad(): acc = ((m(Xv).squeeze(-1) > 0.5).float() == Yv).float().mean().item()
            sch.step(acc)
            if acc > best: best, state = acc, {k: v.clone() for k, v in m.state_dict().items()}
    m.load_state_dict(state); m.eval(); return m, best


def corrupt(occ, p, seed):
    rng = np.random.default_rng(seed); o = occ.copy()
    fp = (~occ) & (rng.random(occ.shape) < p); fn = occ & (rng.random(occ.shape) < p)
    o[fp] = True; o[fn] = False
    N = occ.shape[0]; o[0, 0, 0] = o[N - 1, N - 1, N - 1] = False
    return o


def part_noise(out, levels, seeds, lam):
    N = 50; rows = []
    for name in MAPS:
        true = occ_of(name, N); tedt = distance_transform_edt(~true)
        for p in levels:
            for sd in (seeds if p > 0 else [0]):
                noisy = corrupt(true, p, 100 + sd) if p > 0 else true.copy()
                obs = set(map(tuple, np.argwhere(noisy))); s, g = (0, 0, 0), (N - 1,) * 3
                t = time.perf_counter(); net, vacc = train_net(noisy, sd); t_train = time.perf_counter() - t
                R_nn = dense_nn(net, N); R_edt = edt_risk(noisy)
                fields = {"wA* (no risk)": None, "NACHA*-EDT": R_edt, "NACHA*-NN": R_nn}
                # occupancy agreement with the TRUE map: the EDT field is built on the corrupted occupancy, so its
                # implied occupancy is the corrupted map itself; the network's implied occupancy is rho > 0.5.
                occ_impl = {"wA* (no risk)": noisy, "NACHA*-EDT": noisy, "NACHA*-NN": R_nn > 0.5}
                facc = {k: float((v == true).mean()) for k, v in occ_impl.items()}
                # share of the TRUE free space that the risk field marks as high risk (rho > 0.5): this is what
                # enlarges the search, since every such voxel carries an inflated edge cost
                free_t = ~true
                hr = {"wA* (no risk)": float("nan"), "NACHA*-EDT": float((R_edt[free_t] > 0.5).mean()), "NACHA*-NN": float((R_nn[free_t] > 0.5).mean())}
                ref = NACHAStar(N, set(map(tuple, np.argwhere(true))), lambda0=0, w=1.0).plan(s, g)
                Lref = sum(math.dist(ref[i], ref[i + 1]) for i in range(len(ref) - 1))
                for lab, R in fields.items():
                    pl = NACHAStar(N, obs, lambda0=(lam if R is not None else 0.0), w=1.2, risk_grid=R)
                    path = pl.plan(s, g)
                    r = dict(env=name, p=p, seed=sd, planner=lab, val_acc=vacc, occ_agree_vs_true=facc[lab], highrisk_free=hr[lab], train_s=t_train,
                             success=path is not None, nodes=pl.nodes_expanded)
                    if path is not None:
                        L = sum(math.dist(path[i], path[i + 1]) for i in range(len(path) - 1))
                        r.update(length=L, excess_vs_true_opt_pct=100 * (L / Lref - 1), **clearance_stats(path, tedt, true))
                    rows.append(r)
                print(name, p, sd, f"val={vacc:.3f}", flush=True)
                pd.DataFrame(rows).to_csv(out, index=False)


if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--part", choices=["memory", "noise"], required=True)
    ap.add_argument("--levels", default="0,0.01,0.03,0.05"); ap.add_argument("--seeds", type=int, default=3)
    ap.add_argument("--lam", type=float, default=0.5)
    a = ap.parse_args()
    if a.part == "memory":
        part_memory(os.path.join(BASE, "repr_memory.csv"))
    else:
        part_noise(os.path.join(BASE, "repr_noise.csv"), [float(x) for x in a.levels.split(",")], list(range(a.seeds)), a.lam)
