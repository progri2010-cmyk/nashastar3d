"""
datasets/movingai_loader.py
Loader për MovingAI 3D dataset - Mbështet TË GJITHA 44 mjediset MovingAI

Reference: Sturtevant, 2012 - Benchmarks for Grid-Based Pathfinding

SUPPORTON TË DY FORMATET:
1. Format real 3D: "voxel W H D" + lista koordinata x y z
2. Format ASCII 2D: "height", "width", "map" + grid me karaktere
3. Fallback: Gjenerim i pengesave të rastit për mjedise që nuk ekzistojnë
"""

import os
import numpy as np
import json
import re
import random
from typing import List, Tuple, Dict, Optional, Set


class MovingAI3DLoader:
    """
    Loader për MovingAI dataset të adaptuar për 3D.
    Mbështet 44 mjedise MovingAI standarde.
    """
    
    # Lista e të gjitha mjediseve MovingAI (44)
    ALL_MOVINGAI_MAPS = [
        # Seria A (10)
        'A1', 'A2', 'A3', 'A4', 'A5', 'A6', 'A7', 'A8', 'A9', 'A10',
        # Seria AR (4)
        'AR001', 'AR002', 'AR003', 'AR004',
        # Seria BA (5)
        'BA1', 'BA2', 'BA3', 'BA4', 'BA5',
        # Seria BC (5)
        'BC1', 'BC2', 'BC3', 'BC4', 'BC5',
        # Seria BR (5)
        'BR1', 'BR2', 'BR3', 'BR4', 'BR5',
        # Seria DA (5)
        'DA1', 'DA2', 'DA3', 'DA4', 'DA5',
        # Seria DEN (4)
        'den011d', 'den012d', 'den013d', 'den014d',
        # Seria MAZE (4)
        'maze512', 'maze512-1', 'maze512-2', 'maze512-3',
        # Seria RANDOM (2)
        'random_3d', 'random_3d_dense',
    ]
    
    # Informacion për secilin mjedis
    MAP_INFO = {
        'A1': {'description': 'MovingAI A1 - Dense obstacles', 'difficulty': 'hard', 'density': 0.25},
        'A2': {'description': 'MovingAI A2 - Medium obstacles', 'difficulty': 'medium', 'density': 0.20},
        'A3': {'description': 'MovingAI A3 - Complex obstacles', 'difficulty': 'hard', 'density': 0.30},
        'A4': {'description': 'MovingAI A4 - Mixed obstacles', 'difficulty': 'medium', 'density': 0.22},
        'A5': {'description': 'MovingAI A5 - Dense obstacles', 'difficulty': 'hard', 'density': 0.28},
        'A6': {'description': 'MovingAI A6 - Sparse obstacles', 'difficulty': 'easy', 'density': 0.18},
        'A7': {'description': 'MovingAI A7 - Very dense obstacles', 'difficulty': 'very_hard', 'density': 0.32},
        'A8': {'description': 'MovingAI A8 - Open space', 'difficulty': 'easy', 'density': 0.15},
        'A9': {'description': 'MovingAI A9 - Medium density', 'difficulty': 'medium', 'density': 0.27},
        'A10': {'description': 'MovingAI A10 - Mixed obstacles', 'difficulty': 'medium', 'density': 0.23},
        'AR001': {'description': 'MovingAI AR001 - Dense city', 'difficulty': 'hard', 'density': 0.35},
        'AR002': {'description': 'MovingAI AR002 - Very dense city', 'difficulty': 'very_hard', 'density': 0.40},
        'AR003': {'description': 'MovingAI AR003 - Medium city', 'difficulty': 'medium', 'density': 0.30},
        'AR004': {'description': 'MovingAI AR004 - Dense urban', 'difficulty': 'hard', 'density': 0.38},
        'BA1': {'description': 'MovingAI BA1 - Building area', 'difficulty': 'hard', 'density': 0.35},
        'BA2': {'description': 'MovingAI BA2 - Complex buildings', 'difficulty': 'very_hard', 'density': 0.30},
        'BA3': {'description': 'MovingAI BA3 - Dense buildings', 'difficulty': 'hard', 'density': 0.40},
        'BA4': {'description': 'MovingAI BA4 - Medium buildings', 'difficulty': 'medium', 'density': 0.28},
        'BA5': {'description': 'MovingAI BA5 - Open buildings', 'difficulty': 'medium', 'density': 0.32},
        'BC1': {'description': 'MovingAI BC1 - City area', 'difficulty': 'medium', 'density': 0.20},
        'BC2': {'description': 'MovingAI BC2 - City area 2', 'difficulty': 'medium', 'density': 0.25},
        'BC3': {'description': 'MovingAI BC3 - Dense city', 'difficulty': 'hard', 'density': 0.22},
        'BC4': {'description': 'MovingAI BC4 - Open city', 'difficulty': 'easy', 'density': 0.18},
        'BC5': {'description': 'MovingAI BC5 - Mixed city', 'difficulty': 'medium', 'density': 0.27},
        'BR1': {'description': 'MovingAI BR1 - Residential area', 'difficulty': 'medium', 'density': 0.22},
        'BR2': {'description': 'MovingAI BR2 - Dense residential', 'difficulty': 'hard', 'density': 0.25},
        'BR3': {'description': 'MovingAI BR3 - Open residential', 'difficulty': 'easy', 'density': 0.20},
        'BR4': {'description': 'MovingAI BR4 - Mixed residential', 'difficulty': 'medium', 'density': 0.28},
        'BR5': {'description': 'MovingAI BR5 - Complex residential', 'difficulty': 'hard', 'density': 0.23},
        'DA1': {'description': 'MovingAI DA1 - Open area', 'difficulty': 'easy', 'density': 0.12},
        'DA2': {'description': 'MovingAI DA2 - Sparse obstacles', 'difficulty': 'easy', 'density': 0.15},
        'DA3': {'description': 'MovingAI DA3 - Very open', 'difficulty': 'very_easy', 'density': 0.10},
        'DA4': {'description': 'MovingAI DA4 - Medium open', 'difficulty': 'easy', 'density': 0.18},
        'DA5': {'description': 'MovingAI DA5 - Sparse area', 'difficulty': 'easy', 'density': 0.14},
        'den011d': {'description': 'MovingAI den011d - Dense obstacles 0.11', 'difficulty': 'medium', 'density': 0.30},
        'den012d': {'description': 'MovingAI den012d - Dense obstacles 0.12', 'difficulty': 'medium', 'density': 0.35},
        'den013d': {'description': 'MovingAI den013d - Dense obstacles 0.13', 'difficulty': 'hard', 'density': 0.40},
        'den014d': {'description': 'MovingAI den014d - Dense obstacles 0.14', 'difficulty': 'hard', 'density': 0.25},
        'maze512': {'description': 'MovingAI maze512 - 3D Maze', 'difficulty': 'very_hard', 'density': 0.20},
        'maze512-1': {'description': 'MovingAI maze512-1 - Complex maze', 'difficulty': 'very_hard', 'density': 0.22},
        'maze512-2': {'description': 'MovingAI maze512-2 - Medium maze', 'difficulty': 'hard', 'density': 0.18},
        'maze512-3': {'description': 'MovingAI maze512-3 - Dense maze', 'difficulty': 'very_hard', 'density': 0.25},
        'random_3d': {'description': 'MovingAI random_3d - Random obstacles', 'difficulty': 'medium', 'density': 0.15},
        'random_3d_dense': {'description': 'MovingAI random_3d_dense - Dense random', 'difficulty': 'hard', 'density': 0.30},
    }
    
    def __init__(self, data_dir: str = None):
        """
        Inicializon loader-in.
        
        Args:
            data_dir: Drejtoria ku ndodhen skedarët MovingAI (.3dmap ose .map)
                     Nëse None, përdor 'movingai/all/' në drejtorinë aktuale
        """
        if data_dir is None:
            # Kërko në disa vende të mundshme - PRIORITET movingai/all/
            possible_dirs = [
                os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'movingai', 'all'),
                os.path.join(os.path.dirname(os.path.abspath(__file__)), 'movingai', 'all'),
                os.path.join(os.getcwd(), 'movingai', 'all'),
                os.path.join(os.getcwd(), 'datasets', 'movingai', 'all'),
                # Fallback: provo pa 'all'
                os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'movingai'),
                os.path.join(os.path.dirname(os.path.abspath(__file__)), 'movingai'),
                os.path.join(os.getcwd(), 'movingai'),
                os.path.join(os.getcwd(), 'datasets', 'movingai'),
            ]
            for d in possible_dirs:
                if os.path.exists(d):
                    data_dir = d
                    print(f"[INFO] MovingAI data directory found: {data_dir}")
                    break
            else:
                # Krijo drejtorinë nëse nuk ekziston
                data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'movingai', 'all')
                os.makedirs(data_dir, exist_ok=True)
                print(f"[INFO] MovingAI data directory created: {data_dir}")
        
        self.data_dir = data_dir
        self.scenarios = []
        self.last_source = None
        self._cache = {}  # Cache për të shmangur ngarkime të përsëritura
        self._loaded_count = 0
        self._failed_count = 0
    
    def get_all_maps(self, grid_size: int = 20, force_reload: bool = False) -> Dict[str, List[Tuple[int, int, int]]]:
        """
        Ngarkon TË GJITHA 44 mjediset MovingAI.
        
        Args:
            grid_size: Madhësia e grid-it të destinacionit
            force_reload: Forco ringarkimin (ignore cache)
            
        Returns:
            dict: {map_name: list_of_obstacles}
        """
        all_maps = {}
        loaded_from_file = 0
        loaded_from_fallback = 0
        
        print(f"[INFO] MovingAI: Loading {len(self.ALL_MOVINGAI_MAPS)} maps from {self.data_dir}")
        
        for i, map_name in enumerate(self.ALL_MOVINGAI_MAPS, 1):
            print(f"  [{i:2d}/{len(self.ALL_MOVINGAI_MAPS)}] Loading {map_name}...", end=' ')
            
            obstacles = self.load_map(map_name, grid_size, force_reload)
            
            if obstacles is not None:
                all_maps[map_name] = obstacles
                loaded_from_file += 1
                print(f"[OK] {len(obstacles)} obstacles")
            else:
                # Nëse ngarkimi dështon, gjenero pengesa të rastit
                print(f"[WARN] not found, generating fallback...")
                obstacles = self._generate_fallback_map(map_name, grid_size)
                all_maps[map_name] = obstacles
                loaded_from_fallback += 1
                print(f"      [FALLBACK] {len(obstacles)} obstacles")
        
        print(f"\n[INFO] MovingAI loading complete:")
        print(f"  - Total maps: {len(self.ALL_MOVINGAI_MAPS)}")
        print(f"  - Loaded from files: {loaded_from_file}")
        print(f"  - Generated fallback: {loaded_from_fallback}")
        
        return all_maps
    
    def load_map(self, map_name: str, grid_size: int = 20, force_reload: bool = False) -> Optional[List[Tuple[int, int, int]]]:
        """
        Ngarkon një hartë specifike MovingAI.
        
        Args:
            map_name: Emri i hartës (p.sh., 'A1', 'den011d')
            grid_size: Madhësia e grid-it të destinacionit
            force_reload: Forco ringarkimin (ignore cache)
            
        Returns:
            list: Lista e pengesave ose None nëse nuk gjendet
        """
        cache_key = f"{map_name}_{grid_size}"
        if not force_reload and cache_key in self._cache:
            return self._cache[cache_key]
        
        # Provo të gjitha formatet e mundshme
        obstacles = self._try_load_formats(map_name, grid_size)
        
        if obstacles is not None:
            self._cache[cache_key] = obstacles
            return obstacles
        
        # Nëse nuk gjendet, kthe None
        return None
    
    def _try_load_formats(self, map_name: str, grid_size: int) -> Optional[List[Tuple[int, int, int]]]:
        """
        Provo të gjitha formatet e mundshme të skedarëve.
        """
        # Formatet e mundshme të skedarëve
        possible_files = [
            # Format 3D MovingAI
            (f"{map_name}.3dmap", '3d'),
            (f"{map_name}.map", '3d'),
            # Format ASCII 2D
            (f"{map_name}.map", 'ascii'),
            # Format JSON
            (f"{map_name}.json", 'json'),
            # Format NumPy
            (f"{map_name}.npz", 'numpy'),
        ]
        
        # Lista e drejtorive për të kërkuar
        search_dirs = [
            self.data_dir,
            os.path.join(self.data_dir, 'maps'),
            os.path.join(self.data_dir, '3d'),
            os.path.join(self.data_dir, '2d'),
            os.path.dirname(self.data_dir),  # MovingAI pa 'all'
            os.path.join(os.path.dirname(self.data_dir), 'maps'),
        ]
        
        for file_name, file_format in possible_files:
            for search_dir in search_dirs:
                file_path = os.path.join(search_dir, file_name)
                if os.path.exists(file_path):
                    try:
                        if file_format == '3d':
                            obstacles = self._parse_3d_format(file_path, grid_size)
                        elif file_format == 'ascii':
                            obstacles = self._parse_ascii_format(file_path, grid_size)
                        elif file_format == 'json':
                            obstacles = self._parse_json_format(file_path, grid_size)
                        elif file_format == 'numpy':
                            obstacles = self._parse_numpy_format(file_path, grid_size)
                        else:
                            continue
                        
                        if obstacles:
                            self.last_source = f'file_{file_format}'
                            return obstacles
                    except Exception as e:
                        continue
        
        return None
    
    def _parse_3d_format(self, file_path: str, grid_size: int) -> List[Tuple[int, int, int]]:
        """
        Parser për formatin REAL të MovingAI 3D:
        "voxel W H D" në rreshtin e parë
        Pastaj lista e koordinatave x y z
        """
        with open(file_path, 'r') as f:
            content = f.read()
        
        if not content:
            return []
        
        lines = content.strip().split('\n')
        if not lines:
            return []
        
        # Kontrollo nëse është format "voxel"
        header = lines[0].strip().split()
        if len(header) >= 4 and header[0].lower() == 'voxel':
            try:
                width = int(header[1])
                height = int(header[2])
                depth = int(header[3])
            except (IndexError, ValueError):
                return []
            
            # Lexo koordinatat e voxel-ave
            voxels = []
            for line in lines[1:]:
                line = line.strip()
                if not line or line.startswith('#'):
                    continue
                parts = line.split()
                if len(parts) >= 3:
                    try:
                        x = int(parts[0])
                        y = int(parts[1])
                        z = int(parts[2])
                        if 0 <= x < width and 0 <= y < height and 0 <= z < depth:
                            voxels.append((x, y, z))
                    except ValueError:
                        continue
            
            if not voxels:
                return []
            
            # Konverto në grid
            return self._rescale_voxels(voxels, width, height, depth, grid_size)
        
        return []
    
    def _parse_ascii_format(self, file_path: str, grid_size: int) -> List[Tuple[int, int, int]]:
        """
        Parser për format ASCII 2D të MovingAI.
        
        Formati:
        height 512
        width 512
        map
        ....................
        ....................
        """
        with open(file_path, 'r') as f:
            lines = f.readlines()
        
        if not lines:
            return []
        
        grid_rows = []
        start_reading = False
        height = 0
        width = 0
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
            
            if line.lower().startswith('height'):
                try:
                    height = int(line.split()[1])
                except:
                    pass
                continue
            elif line.lower().startswith('width'):
                try:
                    width = int(line.split()[1])
                except:
                    pass
                continue
            elif line.lower().startswith('map'):
                start_reading = True
                continue
            
            if start_reading:
                # Kontrollo nëse rreshti përmban vetëm karaktere të vlefshme
                if all(c in '.T@O' for c in line):
                    grid_rows.append(line)
        
        if not grid_rows:
            return []
        
        # Përpunimi i grid-it 2D në 3D
        obstacles = []
        for y, row in enumerate(grid_rows):
            for x, char in enumerate(row):
                if char in ['T', '@', 'O']:
                    # Shtrije në 3D me 3 shtresa
                    for z in range(min(3, grid_size)):
                        obstacles.append((x, y, z))
        
        return obstacles
    
    def _parse_json_format(self, file_path: str, grid_size: int) -> List[Tuple[int, int, int]]:
        """
        Parser për format JSON të MovingAI.
        """
        with open(file_path, 'r') as f:
            data = json.load(f)
        
        if isinstance(data, dict):
            if 'obstacles' in data:
                return [(int(x), int(y), int(z)) for x, y, z in data['obstacles']]
            elif 'grid' in data:
                grid = data['grid']
                obstacles = []
                for x in range(len(grid)):
                    for y in range(len(grid[x])):
                        for z in range(len(grid[x][y])):
                            if grid[x][y][z] == 1:
                                obstacles.append((x, y, z))
                return obstacles
        
        return []
    
    def _parse_numpy_format(self, file_path: str, grid_size: int) -> List[Tuple[int, int, int]]:
        """
        Parser për format NumPy .npz.
        """
        data = np.load(file_path)
        
        if 'obstacles' in data:
            obs = data['obstacles']
            return [(int(x), int(y), int(z)) for x, y, z in obs]
        elif 'grid' in data:
            grid = data['grid']
            obstacles = []
            for x in range(grid.shape[0]):
                for y in range(grid.shape[1]):
                    for z in range(grid.shape[2]):
                        if grid[x, y, z] == 1:
                            obstacles.append((x, y, z))
            return obstacles
        
        return []
    
    def _rescale_voxels(self, voxels: List[Tuple[int, int, int]], 
                        width: int, height: int, depth: int, 
                        grid_size: int) -> List[Tuple[int, int, int]]:
        """
        Konverton koordinatat nga hapësira origjinale në grid.
        
        Metoda: Downsampling me binning
        - Çdo voxel origjinal hidhet në një qelizë të grid-it të ri
        - Nëse ka të paktën një voxel në një qelizë, ajo qelizë është pengesë
        """
        obstacles = []
        seen = set()
        
        # Llogarit madhësinë e çdo bin-i
        bin_x = width / grid_size
        bin_y = height / grid_size
        bin_z = depth / grid_size
        
        for x, y, z in voxels:
            # Konverto në indekse të grid-it të ri
            gx = int(x / bin_x) if bin_x > 0 else 0
            gy = int(y / bin_y) if bin_y > 0 else 0
            gz = int(z / bin_z) if bin_z > 0 else 0
            
            # Clamp
            gx = max(0, min(grid_size - 1, gx))
            gy = max(0, min(grid_size - 1, gy))
            gz = max(0, min(grid_size - 1, gz))
            
            point = (gx, gy, gz)
            if point not in seen:
                seen.add(point)
                obstacles.append(point)
        
        return obstacles
    
    def _generate_fallback_map(self, map_name: str, grid_size: int) -> List[Tuple[int, int, int]]:
        """
        Gjeneron pengesa të rastit për mjediset MovingAI (fallback).
        """
        self.last_source = 'fallback_random'
        
        # Merr densitetin nga MAP_INFO
        density = self.MAP_INFO.get(map_name, {}).get('density', 0.20)
        
        # FIX: str hash() is randomised per Python process (PYTHONHASHSEED), which made these
        # maps differ between runs. Use a stable CRC32-based seed instead.
        import zlib
        random.seed(zlib.crc32(map_name.encode()) % 10000)
        
        obstacles = []
        total_cells = grid_size ** 3
        n_obstacles = int(total_cells * density)
        
        # Kufizo numrin maksimal të pengesave
        n_obstacles = min(n_obstacles, total_cells // 2)
        
        attempts = 0
        max_attempts = n_obstacles * 20
        added = 0
        
        while added < n_obstacles and attempts < max_attempts:
            x = random.randint(0, grid_size - 1)
            y = random.randint(0, grid_size - 1)
            z = random.randint(0, grid_size - 1)
            point = (x, y, z)
            if point not in obstacles:
                obstacles.append(point)
                added += 1
            attempts += 1
        
        return obstacles
    
    def get_scenario_info(self, scenario_name: str) -> Dict:
        """
        Kthen informacion rreth skenarit.
        """
        return self.MAP_INFO.get(scenario_name, {
            'description': 'Unknown MovingAI map',
            'difficulty': 'medium',
            'density': 0.20
        })
    
    def get_all_scenario_info(self) -> Dict:
        """Kthen informacion për të gjitha skenarët."""
        return self.MAP_INFO.copy()
    
    def get_map_density(self, map_name: str) -> float:
        """Kthen densitetin e pengesave për një hartë."""
        return self.MAP_INFO.get(map_name, {}).get('density', 0.20)
    
    def get_map_difficulty(self, map_name: str) -> str:
        """Kthen vështirësinë e një harte."""
        return self.MAP_INFO.get(map_name, {}).get('difficulty', 'medium')


# ============================================================
# FUNKSIONE NDIHMËSE
# ============================================================

def load_movingai_map(map_name: str, grid_size: int = 20, data_dir: str = None) -> Optional[List[Tuple[int, int, int]]]:
    """
    Funksion ndihmës për të ngarkuar një hartë MovingAI.
    
    Args:
        map_name: Emri i hartës (p.sh., 'A1', 'den011d')
        grid_size: Madhësia e grid-it të destinacionit
        data_dir: Drejtoria e të dhënave
        
    Returns:
        list: Lista e pengesave ose None
    """
    loader = MovingAI3DLoader(data_dir)
    return loader.load_map(map_name, grid_size)


def load_all_movingai_maps(grid_size: int = 20, data_dir: str = None) -> Dict[str, List[Tuple[int, int, int]]]:
    """
    Funksion ndihmës për të ngarkuar TË GJITHA 44 hartat MovingAI.
    
    Args:
        grid_size: Madhësia e grid-it të destinacionit
        data_dir: Drejtoria e të dhënave
        
    Returns:
        dict: {map_name: list_of_obstacles}
    """
    loader = MovingAI3DLoader(data_dir)
    return loader.get_all_maps(grid_size)


def get_movingai_map_names() -> List[str]:
    """
    Kthen listën e të gjitha emrave të hartave MovingAI.
    """
    return MovingAI3DLoader.ALL_MOVINGAI_MAPS.copy()


def get_movingai_map_info(map_name: str) -> Dict:
    """Kthen informacion për një hartë MovingAI."""
    return MovingAI3DLoader.MAP_INFO.get(map_name, {
        'description': 'Unknown MovingAI map',
        'difficulty': 'medium',
        'density': 0.20
    })


def get_movingai_all_info() -> Dict:
    """Kthen informacion për të gjitha hartat MovingAI."""
    return MovingAI3DLoader.MAP_INFO.copy()


# ============================================================
# TEST I SHPEJTË
# ============================================================
if __name__ == "__main__":
    print("=" * 70)
    print("🧪 TESTING MOVINGAI LOADER - 44 ENVIRONMENTS")
    print("=" * 70)
    
    # Krijo loader-in
    loader = MovingAI3DLoader()
    print(f"\n[INFO] Data directory: {loader.data_dir}")
    
    # Testo ngarkimin e të gjitha hartave
    print("\n[INFO] Loading all MovingAI maps (grid_size=20)...")
    all_maps = loader.get_all_maps(grid_size=20)
    
    print(f"\n[OK] Loaded {len(all_maps)} maps")
    
    # Shfaq përmbledhje
    print("\n📋 Map summary:")
    print("-" * 60)
    
    # Grupimi sipas serive
    series = {}
    for name in all_maps.keys():
        if name.startswith('A') and len(name) <= 3:
            key = 'A Series'
        elif name.startswith('AR'):
            key = 'AR Series'
        elif name.startswith('BA'):
            key = 'BA Series'
        elif name.startswith('BC'):
            key = 'BC Series'
        elif name.startswith('BR'):
            key = 'BR Series'
        elif name.startswith('DA'):
            key = 'DA Series'
        elif name.startswith('den'):
            key = 'DEN Series'
        elif name.startswith('maze'):
            key = 'MAZE Series'
        elif name.startswith('random'):
            key = 'RANDOM Series'
        else:
            key = 'Other'
        
        if key not in series:
            series[key] = []
        series[key].append(name)
    
    for series_name, maps in series.items():
        print(f"\n  {series_name} ({len(maps)} maps):")
        for name in maps[:5]:
            obs_count = len(all_maps[name])
            info = loader.get_scenario_info(name)
            print(f"    {name:15} : {obs_count:6} obstacles - {info['description']}")
        if len(maps) > 5:
            print(f"    ... and {len(maps) - 5} more")
    
    # Testo një hartë specifike
    print("\n[INFO] Testing specific map: 'den011d'")
    obstacles = loader.load_map('den011d', grid_size=20)
    if obstacles:
        print(f"  [OK] Loaded {len(obstacles)} obstacles")
        print(f"  Source: {loader.last_source}")
    
    print("\n" + "=" * 70)
    print("✅ TEST COMPLETED SUCCESSFULLY")
    print("=" * 70)