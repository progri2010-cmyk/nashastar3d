# datasets/stanford3d_loader.py
"""
Loader për Stanford 3D datasets
"""

import numpy as np
import os
import json

class Stanford3DLoader:
    """Loader për Stanford 3D Indoor Spaces"""
    
    def __init__(self, data_dir):
        self.data_dir = data_dir
        self.datasets = {
            'area_1': 'Stanford 3D Area 1 - Conference Room',
            'area_2': 'Stanford 3D Area 2 - Office Space',
            'area_3': 'Stanford 3D Area 3 - Hallway',
            'area_4': 'Stanford 3D Area 4 - Auditorium'
        }
    
    def load_area(self, area_name):
        """
        Ngarkon një zonë nga Stanford 3D dataset.
        Nëse skedari nuk gjendet, gjeneron pengesa të rastit (fallback).
        """
        # ============================================================
        # 1. PROVO TË NGARKOSH NGA SKEDARËT REALË
        # ============================================================
        
        # Provo struktura të ndryshme skedarësh
        possible_paths = [
            os.path.join(self.data_dir, f"{area_name}.json"),
            os.path.join(self.data_dir, area_name, f"{area_name}.json"),
            os.path.join(self.data_dir, f"{area_name}.npy"),
            os.path.join(self.data_dir, area_name, f"{area_name}.npy"),
        ]
        
        for file_path in possible_paths:
            if os.path.exists(file_path):
                print(f"   📂 Stanford: Duke ngarkuar {file_path}")
                try:
                    obstacles = self._parse_stanford_file(file_path)
                    if obstacles:
                        print(f"   ✅ Ngarkova {len(obstacles)} pengesa nga {os.path.basename(file_path)}")
                        return obstacles
                except Exception as e:
                    print(f"   ❌ Gabim gjatë leximit të {file_path}: {e}")
        
        # ============================================================
        # 2. FALLBACK: GJENERO PENgesa TË RASTIT (SI MË PARË)
        # ============================================================
        print(f"   🎲 Stanford: Duke gjeneruar pengesa të rastit për '{area_name}' (fallback)")
        return self._generate_random_obstacles(area_name)
    
    def _parse_stanford_file(self, file_path):
        """Parser për skedarët e Stanford 3D"""
        
        if file_path.endswith('.json'):
            with open(file_path, 'r') as f:
                data = json.load(f)
                if 'obstacles' in data:
                    return data['obstacles']
                elif 'points' in data:
                    # Konverto point cloud në pengesa në grid 20x20x20
                    return self._points_to_obstacles(data['points'])
                else:
                    return None
        
        elif file_path.endswith('.npy'):
            data = np.load(file_path)
            if data.ndim == 2 and data.shape[1] == 3:
                return [(int(p[0]), int(p[1]), int(p[2])) for p in data]
            return None
        
        return None
    
    def _points_to_obstacles(self, points, grid_size=20):
        """Konverton point cloud në pengesa në grid"""
        obstacles = []
        for p in points:
            x = int(p[0] * grid_size) if p[0] < 1 else int(p[0]) % grid_size
            y = int(p[1] * grid_size) if p[1] < 1 else int(p[1]) % grid_size
            z = int(p[2] * grid_size) if p[2] < 1 else int(p[2]) % grid_size
            obstacles.append((x, y, z))
        return obstacles
    
    def _generate_random_obstacles(self, area_name):
        """Metodë ndihmëse për të gjeneruar pengesa të rastit (fallback)"""
        import zlib
        np.random.seed(42 + zlib.crc32(area_name.encode()) % 1000)
        
        # Gjenerojmë pengesa të bazuara në strukturën tipike të dhomave
        if area_name == 'area_1':  # Conference Room
            obstacles = []
            for x in range(20):
                for y in range(20):
                    for z in range(20):
                        if (x < 2 or x > 17 or y < 2 or y > 17) and z > 5:
                            obstacles.append((x, y, z))
        
        elif area_name == 'area_2':  # Office Space
            obstacles = []
            for _ in range(200):
                x = np.random.randint(3, 17)
                y = np.random.randint(3, 17)
                z = np.random.randint(2, 18)
                obstacles.append((x, y, z))
        
        elif area_name == 'area_3':  # Hallway
            obstacles = []
            for x in range(20):
                for y in range(20):
                    for z in range(20):
                        if (y < 3 or y > 16) and z > 5:
                            obstacles.append((x, y, z))
        
        else:  # Auditorium ose tjetër
            obstacles = []
            for x in range(20):
                for y in range(20):
                    for z in range(20):
                        if (5 <= x <= 14 and 5 <= y <= 14) and z > 3:
                            obstacles.append((x, y, z))
        
        return obstacles
    
    def get_area_info(self, area_name):
        return {
            'name': area_name,
            'description': self.datasets.get(area_name, 'Unknown'),
            'type': area_name.split('_')[0] if '_' in area_name else 'unknown'
        }
