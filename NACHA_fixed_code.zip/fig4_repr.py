import numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.ticker import FixedLocator, NullLocator, FuncFormatter
B,O,A='#2a78d6','#eb6834','#1baf7a'; INK='#0b0b0b'; INK2='#52514e'; GRID='#e4e3df'
plt.rcParams.update({'font.family':'DejaVu Serif','font.size':8.5,'axes.edgecolor':INK2,'axes.labelcolor':INK,'xtick.color':INK2,'ytick.color':INK2,'axes.spines.top':False,'axes.spines.right':False})
m=pd.read_csv('user_run/repr_memory.csv'); n=pd.read_csv('user_run/repr_noise.csv')
NET_KB=(11329+448)*4/1024
fig,axs=plt.subplots(1,3,figsize=(7.2,2.9))
g=m.groupby('N').agg(occ=('occ_MB','first'),field=('field_MB','first'),lazy=('lazy_cache_MB','mean')).reset_index()
ax=axs[0]
ax.plot(g.N,g.occ*1024,color=INK2,marker='o',lw=2,ms=5,label='occupancy grid')
ax.plot(g.N,(g.occ+g.field)*1024,color=B,marker='s',lw=2,ms=5,ls='--',label='grid + EDT')
ax.plot(g.N,[NET_KB]*len(g),color=O,marker='^',lw=2,ms=5,label='network')
ax.set_xscale('log'); ax.set_yscale('log'); ax.xaxis.set_major_locator(FixedLocator([20,50,100,200])); ax.xaxis.set_minor_locator(NullLocator()); ax.xaxis.set_major_formatter(FuncFormatter(lambda v,p:f'{v:.0f}'))
ax.set_xlabel('Grid size N (N$^3$ voxels)'); ax.set_ylabel('Memory (KB, log scale)'); ax.set_title('(a) map representation size',fontsize=8.5,color=INK)
ax.legend(frameon=False,fontsize=6.3,loc='upper left')
lab={'wA* (no risk)':('wA*, no risk field',INK2,'o',':'),'NACHA*-EDT':('NACHA*, EDT of noisy map',B,'s','--'),'NACHA*-NN':('NACHA*, network on noisy map',O,'^','-')}
q=n.groupby(['p','planner']).agg(facc=('highrisk_free','mean'),nodes=('nodes','mean'),coll=('collision','mean')).reset_index()
for k,(l,c,mk,ls) in lab.items():
    x=q[q.planner==k]
    if k!='wA* (no risk)': axs[1].plot(100*x.p,100*x.facc,color=c,marker=mk,ls=ls,lw=2,ms=5,label=l)
    axs[2].plot(100*x.p,x.nodes,color=c,marker=mk,ls=ls,lw=2,ms=5,label=l)
axs[1].set_xlabel('Voxels flipped by noise, p (%)'); axs[1].set_ylabel('True free space with ρ > 0.5 (%)'); axs[1].set_ylim(0,100); axs[1].set_title('(b) free space marked high-risk',fontsize=8.5,color=INK)
axs[2].set_yscale('log'); axs[2].set_xlabel('Voxels flipped by noise, p (%)'); axs[2].set_ylabel('Node expansions (log scale)'); axs[2].set_title('(c) search effort',fontsize=8.5,color=INK)
h,l=axs[2].get_legend_handles_labels(); fig.legend(h,l,loc='lower center',ncol=3,frameon=False,fontsize=7)
for a in axs: a.grid(True,color=GRID,lw=0.6); a.set_axisbelow(True)
for a in axs[1:]: a.set_xticks([0,1,3,5])
plt.tight_layout(rect=(0,0.08,1,1)); plt.savefig('user_run/figs/fig4_representation.png',dpi=300)
