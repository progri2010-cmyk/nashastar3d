"""
lambda_sweep.py — speed/safety trade-off of NACHA* as a function of (w, lambda0).
Structured environments where the neural field is reliable (val. accuracy >= 0.75).
Usage: python lambda_sweep.py --grid 50
"""
import argparse, math, sys, os, time
import numpy as np
import pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from benchmark_fair import load_environments, neural_risk, path_len
from nacha_planner.nacha_star import NACHAStar
from scipy.ndimage import distance_transform_edt

ENVS = ["cube", "spheres", "wall_xy", "wall_xz", "wall_xy+wall_xz", "wall_xz+cube",
        "random_dense+wall_xy", "stanford_area_2", "stanford_area_4"]
LAMBDAS = [0.0, 0.1, 0.25, 0.5, 1.0]
WEIGHTS = [1.0, 1.2]

ap = argparse.ArgumentParser(); ap.add_argument("--grid", type=int, default=50)
a = ap.parse_args(); N = a.grid
envs = load_environments(N)
rows = []
for name in ENVS:
    src, raw = envs[name]
    s, g = (0, 0, 0), (N - 1,) * 3
    obs = set(map(tuple, raw)); obs.discard(s); obs.discard(g)
    occ = np.zeros((N,) * 3, bool)
    for o in obs: occ[o] = True
    edt = distance_transform_edt(~occ)
    risk, _ = neural_risk(name, N)
    acc = float(((risk > 0.5) == occ).mean())
    ref = None
    for w in WEIGHTS:
        for lam in LAMBDAS:
            pl = NACHAStar(N, obs, lambda0=lam, w=w, risk_grid=risk if lam > 0 else None)
            t = time.perf_counter(); p = pl.plan(s, g); dt = time.perf_counter() - t
            if p is None:
                rows.append(dict(env=name, w=w, lambda0=lam, success=False)); continue
            L = path_len(p)
            if w == 1.0 and lam == 0.0: ref = L
            cl = [edt[q] for q in p[1:-1]]
            rows.append(dict(env=name, w=w, lambda0=lam, success=True, nodes=pl.nodes_expanded,
                             time_s=dt, length=L, subopt_pct=100 * (L / ref - 1),
                             min_clearance=min(cl), mean_clearance=float(np.mean(cl)),
                             frac_within_2=float(np.mean(np.array(cl) <= 2.0)),
                             nn_accuracy=acc,
                             bound=w * (1 + 2 * lam)))
    print(name, flush=True)
pd.DataFrame(rows).to_csv(f"lambda_sweep_grid{N}.csv", index=False)
