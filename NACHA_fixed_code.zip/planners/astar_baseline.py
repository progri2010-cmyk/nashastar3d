"""
A* baseline — corrected for a fair comparison.

Same data structures and tie-breaking as NACHA* (CLOSED list, FIFO counter,
precomputed step costs). It is exactly NACHA* with lambda0 = 0 and w = 1,
so any difference in the benchmark comes from the algorithm, not the code.
"""
from nacha_planner.nacha_star import NACHAStar


class AStarBaseline(NACHAStar):
    def __init__(self, grid_size, obstacles, **kwargs):
        super().__init__(grid_size=grid_size, obstacles=obstacles,
                         env_model=None, lambda0=0.0, w=1.0)
