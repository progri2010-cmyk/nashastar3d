# NACHA* — corrected code (replace these files in the project)

Fixed files
- models/env_model_loader.py      : predict_batch() crashed on numpy arrays (`if not points`), so the
                                    neural risk field was silently all zeros in every previous benchmark.
- nacha_planner/neural_cost_function.py : now raises an error instead of silently using a zero field.
- nacha_planner/nacha_star.py     : CLOSED list, explicit heuristic weight `w`, accepts precomputed risk_grid.
- planners/astar_baseline.py      : A* = NACHA* with w=1, lambda0=0 (same code, fair comparison).

New scripts (reproduce every table/figure of the revised manuscript)
- benchmark_fair.py   python benchmark_fair.py --grid 20 --runs 3 --jobs 2
                      python benchmark_fair.py --grid 50 --runs 3 --jobs 2
- lambda_sweep.py     python lambda_sweep.py --grid 50
- analyze.py          aggregates (reads val_acc.json = validation accuracy stored in each .pt)
- make_figs.py        Figures 1-3

Results included: fair_benchmark_grid20.csv, fair_benchmark_grid50.csv, lambda_sweep_grid50.csv,
analysis_grid20.csv, analysis_grid50.csv, val_acc.json.
Node counts, path lengths and clearances are deterministic; re-run on your workstation to replace times.
