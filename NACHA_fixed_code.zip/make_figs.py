import sys,os,math,numpy as np,pandas as pd,matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
sys.path.insert(0,'.')
from benchmark_fair import load_environments, neural_risk
from nacha_planner.nacha_star import NACHAStar
from scipy.ndimage import distance_transform_edt
B,O,A='#2a78d6','#eb6834','#1baf7a'; INK='#0b0b0b'; INK2='#52514e'; GRID='#e4e3df'
plt.rcParams.update({'font.family':'DejaVu Serif','font.size':9,'axes.edgecolor':INK2,'axes.labelcolor':INK,'xtick.color':INK2,'ytick.color':INK2,'axes.spines.top':False,'axes.spines.right':False})

# ---------- Fig 1 flowchart
fig,ax=plt.subplots(figsize=(5.2,7.4)); ax.axis('off'); ax.set_xlim(0,10); ax.set_ylim(0,20)
def box(x,y,w,h,t,fc='#f3f7fd',ec=B,fs=8.3):
    ax.add_patch(FancyBboxPatch((x-w/2,y-h/2),w,h,boxstyle='round,pad=0.12',fc=fc,ec=ec,lw=1.1))
    ax.text(x,y,t,ha='center',va='center',fontsize=fs,color=INK)
def arr(x1,y1,x2,y2,t=None):
    ax.annotate('',xy=(x2,y2),xytext=(x1,y1),arrowprops=dict(arrowstyle='-|>',color=INK2,lw=1))
    if t: ax.text((x1+x2)/2+0.15,(y1+y2)/2,t,fontsize=7.5,color=INK2,va='center')
box(5,19,7.4,1.2,'Input: voxel map $\\mathcal{X}$, $s_{start}$, $s_{goal}$, trained model $\\mathcal{M}_\\theta$,\n$w$, $\\lambda_0$, reliability threshold $\\tau$',fc='#eef7f2',ec=A)
box(5,16.9,7.4,1.3,'1. Reliability gate\nif val. accuracy of $\\mathcal{M}_\\theta<\\tau$ (or no model):  $\\lambda_0\\leftarrow 0$',fc='#fdf1ec',ec=O)
box(5,14.7,7.4,1.3,'2. Risk-field precomputation (once per map)\n$\\rho=\\mathcal{M}_\\theta(\\mathrm{all}\\ N^3\\ \\mathrm{voxels})$, one batched forward pass')
box(5,12.5,7.4,1.1,'3. OPEN $\\leftarrow\\{s_{start}\\}$,  CLOSED $\\leftarrow\\emptyset$,  $g(s_{start})=0$')
box(5,10.4,7.4,1.3,'4. Pop $s$ with minimum $f$; skip if $s\\in$ CLOSED\nif $s=s_{goal}$: return path;  else CLOSED $\\leftarrow s$')
box(5,7.9,7.4,1.7,"5. For each 26-neighbour $s'\\notin\\mathcal{X}_{obs}\\cup$CLOSED:\n$c'(s,s')=c(s,s')\\,[1+\\lambda_{eff}(s')\\,\\rho(s')]$  (O(1) lookup)\n$\\lambda_{eff}(s')=\\lambda_0\\,(1+\\rho(s'))$")
box(5,5.3,7.4,1.4,"6. If $g(s)+c'(s,s')<g(s')$: update $g(s')$, parent\npush $f(s')=g(s')+w\\,h_{Euc}(s',s_{goal})$ into OPEN")
box(5,3.1,7.4,1.0,'OPEN empty  $\\Rightarrow$  report INFEASIBLE',fc='#f6f6f4',ec=INK2)
box(5,1.2,7.4,1.3,'Guarantee: $c(P)\\leq w\\,(1+2\\lambda_0)\\,c(P^*)$\n(geometric path cost; Theorem 1)',fc='#eef7f2',ec=A)
for y1,y2 in [(18.4,17.6),(16.25,15.35),(14.05,13.05),(11.95,11.05),(9.75,8.75),(7.05,6.0),(4.6,3.6)]: arr(5,y1,5,y2)
ax.annotate('',xy=(8.9,10.4),xytext=(8.9,5.3),arrowprops=dict(arrowstyle='-|>',color=INK2,lw=1,connectionstyle='arc3,rad=0'))
ax.plot([8.75,8.9],[5.3,5.3],color=INK2,lw=1); ax.text(9.05,7.85,'loop',rotation=90,fontsize=7.5,color=INK2,va='center')
plt.tight_layout(); plt.savefig('figs/fig1_flowchart.png',dpi=300); plt.close()

# ---------- Fig 3 trade-off (volumetric maps)
d=pd.read_csv('lambda_sweep_grid50.csv'); v=d[d.env.isin(['cube','spheres','stanford_area_4'])&(d.success==True)]
t=v.groupby(['w','lambda0']).agg(nodes=('nodes','mean'),near=('frac_within_2','mean'),minc=('min_clearance','mean'),sub=('subopt_pct','mean')).reset_index()
astar=t[(t.w==1.0)&(t.lambda0==0)].nodes.iloc[0]
fig,axs=plt.subplots(1,2,figsize=(7,2.9))
for w,c,m,ls,lab in [(1.0,B,'o','-','$w=1.0$ (neural cost only)'),(1.2,O,'s','--','$w=1.2$ (NACHA*)')]:
    q=t[t.w==w]
    axs[0].plot(q.nodes,100*q.near,color=c,marker=m,ls=ls,lw=2,ms=6,label=lab)
    axs[1].plot(q['sub'],q.minc,color=c,marker=m,ls=ls,lw=2,ms=6,label=lab)
    for _,r in q.iterrows():
        if r.lambda0 in (0.5,): continue
        off={0.0:(6,3),0.1:(6,3),0.25:(6,3),1.0:(-4,-11)}[r.lambda0]
        axs[0].annotate(f"$\\lambda_0$={r.lambda0:g}",(r.nodes,100*r.near),textcoords='offset points',xytext=off,fontsize=6.8,color=INK2)
axs[0].set_xscale('log'); axs[0].set_ylim(-4,33); axs[0].set_xlabel('Mean node expansions (log scale)'); axs[0].set_ylabel('Path fraction within 2 voxels\nof an obstacle (%)')
axs[1].set_xlabel('Mean path-length sub-optimality (%)'); axs[1].set_ylabel('Mean minimum clearance (voxels)')
for a in axs: a.grid(True,color=GRID,lw=0.6); a.set_axisbelow(True)
axs[0].legend(frameon=False,fontsize=7.5,loc='upper right')
axs[0].set_title('(a) search effort vs. near-obstacle exposure',fontsize=8.5,color=INK); axs[1].set_title('(b) path length vs. clearance',fontsize=8.5,color=INK)
plt.tight_layout(); plt.savefig('figs/fig3_tradeoff.png',dpi=300); plt.close()

# ---------- Fig 2 spheres paths + clearance profile
N=50; envs=load_environments(N)
fig=plt.figure(figsize=(7,3.1))
for k,name in enumerate(['spheres','cube']):
    raw=envs[name][1]; s,g=(0,0,0),(N-1,)*3
    obs=set(map(tuple,raw)); obs.discard(s); obs.discard(g)
    occ=np.zeros((N,)*3,bool)
    for o in obs: occ[o]=True
    edt=distance_transform_edt(~occ); risk,_=neural_risk(name,N)
    ax=fig.add_subplot(1,2,k+1)
    for lab,kw,c,ls in [('A* (optimal)',dict(w=1.0,lambda0=0),INK2,':'),('wA* ($w$=1.2)',dict(w=1.2,lambda0=0),B,'--'),('NACHA* ($w$=1.2, $\\lambda_0$=0.5)',dict(w=1.2,lambda0=0.5,risk_grid=risk),O,'-')]:
        p=NACHAStar(N,obs,**kw).plan(s,g)
        L=np.cumsum([0]+[math.dist(p[i],p[i+1]) for i in range(len(p)-1)])
        ax.plot(L/L[-1],[edt[q] for q in p],color=c,ls=ls,lw=2,label=lab)
    ax.axhspan(0,2,color='#fdf1ec',zorder=0); ax.text(0.0,0.4,'≤ 2 voxels from obstacle',fontsize=6.8,color=INK2,ha='left',va='bottom')
    ax.set_xlabel('Normalised position along path'); ax.set_ylabel('Clearance (voxels)'); ax.set_ylim(0,None)
    ax.set_title(f'({"ab"[k]}) {name}, $50^3$',fontsize=8.5,color=INK); ax.grid(True,color=GRID,lw=0.6); ax.set_axisbelow(True)
    if k==0: ax.legend(frameon=False,fontsize=7,loc='upper center')
plt.tight_layout(); plt.savefig('figs/fig2_clearance.png',dpi=300); plt.close()
print('ok')
