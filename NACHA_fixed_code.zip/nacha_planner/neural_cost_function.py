# nacha_planner/neural_cost_function.py
"""
Neural Adaptive Cost Function me Pre-computation/Caching për performancë maksimale.
"""

import torch
import numpy as np


class NeuralAdaptiveCostFunction:
    def __init__(self, env_model, lambda0=1.0, use_adaptive_lambda=False, grid_size=20):
        self.env_model = env_model
        self.lambda0 = lambda0
        self.use_adaptive_lambda = use_adaptive_lambda
        self.grid_size = int(grid_size)

        # Nxjerrim modelin e brendshëm PyTorch
        if hasattr(self.env_model, 'model'):
            self.net = self.env_model.model
        elif hasattr(self.env_model, 'net'):
            self.net = self.env_model.net
        elif hasattr(self.env_model, 'torch_model'):
            self.net = self.env_model.torch_model
        else:
            self.net = self.env_model

        # 🚀 Llogaritim riskun për të gjithë mjedisin 3D vetëm 1 herë në start!
        self.risk_grid = self._precompute_entire_grid()

    def _precompute_entire_grid(self):
        """
        Parallogarit rreziqet (risk grid) për të gjithë mjedisin 3D.
        Mbron ekzekutimin edhe nëse modeli kthen float apo numpy array.
        """
        if self.env_model is None:
            # Fallback nëse s'ka model neural: kthen matricë me zero
            return np.zeros((self.grid_size, self.grid_size, self.grid_size), dtype=np.float32)

        try:
            # Thirrja e modelit për parashikim të plotë
            preds = self.env_model.predict_grid(self.grid_size) # ose mënyra si e thërret modeli yt
            
            # 1. Nëse kthen thjesht një 'float' apo 'int'
            if isinstance(preds, (float, int)):
                return np.full((self.grid_size, self.grid_size, self.grid_size), float(preds), dtype=np.float32)

            # 2. Nëse kthen PyTorch Tensor
            if isinstance(preds, torch.Tensor):
                preds = preds.detach().cpu().numpy()

            # 3. Nëse kthen NumPy Array
            if isinstance(preds, np.ndarray):
                if preds.size == self.grid_size ** 3:
                    return preds.reshape(self.grid_size, self.grid_size, self.grid_size)
                raise RuntimeError(f"Risk field has {preds.size} values, expected {self.grid_size**3}")

        except Exception as e:
            # FIX: fail loudly. A silent zero field turns NACHA* into plain weighted A*.
            raise RuntimeError(f"Neural risk-field precomputation failed: {e}") from e

    def compute_batch_costs(self, current, neighbors):
        """Marrja e kostove me shpejtësi O(1) nga memoria."""
        if not neighbors:
            return []

        curr_arr = np.array(current, dtype=np.float32)
        neigh_arr = np.array(neighbors, dtype=np.float32)

        # Distanca Euklidiane bazë
        base_dists = np.linalg.norm(neigh_arr - curr_arr, axis=1)

        # Çasje direkte O(1) në matricën e parallogaritur
        idx = np.array(neighbors, dtype=int)
        risks = self.risk_grid[idx[:, 0], idx[:, 1], idx[:, 2]]

        # Llogaritja e Lambdas
        if self.use_adaptive_lambda:
            eff_lambda = self.lambda0 * (1.0 + risks)
        else:
            eff_lambda = self.lambda0

        # Cost = Base_Dist * (1 + Lambda * Risk)
        neural_costs = base_dists * (1.0 + eff_lambda * risks)

        return neural_costs.tolist()
