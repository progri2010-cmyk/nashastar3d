# nacha_planner/nacha_star.py
"""
NACHA* (Neural-Adaptive Cost-Heuristic A*) — corrected reference implementation.

Evaluation function (matches the manuscript, Eq. 5-7 revised):
    f(s') = g'(s') + w * h_Euc(s', goal)
    c'(s, s') = c(s, s') * (1 + lambda_eff(s') * rho(s'))
    lambda_eff(s') = lambda0 * (1 + rho(s'))   (adaptive)   or   lambda0   (static)

rho(s) in [0, 1] is the neural obstacle-risk field, precomputed once per query
with a single batched forward pass (O(1) lookup during search).

Guarantee (Theorem 1, revised): with a CLOSED list and no re-opening,
    c(P) <= w * (1 + 2*lambda0) * c(P*)        (adaptive regime)
    c(P) <= w * (1 +   lambda0) * c(P*)        (static regime)
where c is the geometric (Euclidean) path cost.

Changes vs. the previous version:
  * CLOSED list (no duplicate expansions; nodes_expanded counts unique expansions).
  * Heuristic weight `w` is an explicit parameter (previously hard-coded 1.2
    and only switched on when the neural model was active, which confounded
    the ablation).
  * Neural field failures raise instead of silently falling back to zeros.
"""

import heapq
import math

_MOVES = [(dx, dy, dz)
          for dx in (-1, 0, 1) for dy in (-1, 0, 1) for dz in (-1, 0, 1)
          if (dx, dy, dz) != (0, 0, 0)]
_STEP = [math.sqrt(dx * dx + dy * dy + dz * dz) for dx, dy, dz in _MOVES]


class NACHAStar:
    def __init__(self, grid_size=20, obstacles=None, env_model=None,
                 lambda0=0.1, use_adaptive_lambda=True, w=1.2,
                 max_expansions=10_000_000, risk_grid=None):
        self.grid_size = int(grid_size)
        self.obstacles = set(tuple(o[:3]) for o in obstacles) if obstacles is not None else set()
        self.env_model = env_model
        self.lambda0 = float(lambda0)
        self.use_adaptive_lambda = use_adaptive_lambda
        self.w = float(w)
        self.max_expansions = max_expansions
        self.nodes_expanded = 0
        self.risk = None
        if self.lambda0 > 0:
            if risk_grid is not None:
                self.risk = risk_grid
            elif env_model is not None:
                from .neural_cost_function import NeuralAdaptiveCostFunction
                self.risk = NeuralAdaptiveCostFunction(
                    env_model=env_model, lambda0=self.lambda0,
                    use_adaptive_lambda=use_adaptive_lambda,
                    grid_size=self.grid_size).risk_grid
            else:
                raise ValueError("lambda0 > 0 requires env_model or risk_grid")

    def _multiplier(self, v):
        if self.risk is None:
            return 1.0
        r = float(self.risk[v])
        lam = self.lambda0 * (1.0 + r) if self.use_adaptive_lambda else self.lambda0
        return 1.0 + lam * r

    def plan(self, start, goal):
        self.nodes_expanded = 0
        s, g = tuple(start[:3]), tuple(goal[:3])
        N, obs, w = self.grid_size, self.obstacles, self.w
        if s in obs or g in obs:
            return None
        counter = 0
        open_set = [(w * math.dist(s, g), 0, s)]
        g_score = {s: 0.0}
        came_from = {}
        closed = set()
        while open_set and self.nodes_expanded < self.max_expansions:
            _, _, u = heapq.heappop(open_set)
            if u in closed:
                continue
            closed.add(u)
            self.nodes_expanded += 1
            if u == g:
                path = [u]
                while path[-1] in came_from:
                    path.append(came_from[path[-1]])
                return path[::-1]
            gu = g_score[u]
            for (dx, dy, dz), step in zip(_MOVES, _STEP):
                v = (u[0] + dx, u[1] + dy, u[2] + dz)
                if not (0 <= v[0] < N and 0 <= v[1] < N and 0 <= v[2] < N):
                    continue
                if v in obs or v in closed:
                    continue
                t = gu + step * self._multiplier(v)
                if t < g_score.get(v, math.inf):
                    g_score[v] = t
                    came_from[v] = u
                    counter += 1
                    heapq.heappush(open_set, (t + w * math.dist(v, g), counter, v))
        return None
